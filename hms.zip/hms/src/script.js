let patients = [];

// Function to add a new patient
function addPatient() {
  const name = document.getElementById("name").value;
  const age = document.getElementById("age").value;
  const gender = document.getElementById("gender").value;

  if (name && age && gender) {
    // Add patient to array
    patients.push({ name, age, gender });
    renderTable();

    // Clear form inputs
    document.getElementById("name").value = '';
    document.getElementById("age").value = '';
    document.getElementById("gender").value = '';
  } else {
    alert("Please fill out all fields.");
  }
}

// Function to delete a patient
function deletePatient(index) {
  patients.splice(index, 1);  // Remove patient from array
  renderTable();
}

// Function to render patient table
function renderTable() {
  const tableBody = document.getElementById("patientTableBody");
  tableBody.innerHTML = ''; // Clear existing rows

  patients.forEach((patient, index) => {
    const row = document.createElement("tr");
    
    row.innerHTML = `
      <td>${patient.name}</td>
      <td>${patient.age}</td>
      <td>${patient.gender}</td>
      <td><button onclick="deletePatient(${index})">Delete</button></td>
    `;

    tableBody.appendChild(row);
  });
}